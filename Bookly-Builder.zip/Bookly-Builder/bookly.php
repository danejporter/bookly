<?php
/**
 * Plugin Name: Bookly Site Builder
 * Description: The most advanced frontend drag & drop page builder. Create high-end, pixel perfect websites at record speeds. Any theme, any page, any design.
 * Plugin URI: https://bookly.com.au/
 * Author: Bookly.com.au
 * Version: 0.4.1
 * Author URI: https://bookly.com.au/
 *
 * Text Domain: bookly
 *
 * Bookly is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.
 *
 * Bookly is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
*/

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

define( 'BOOKLY_VERSION', '0.4.1' );

define( 'BOOKLY__FILE__', __FILE__ );
define( 'BOOKLY_PLUGIN_BASE', plugin_basename( BOOKLY__FILE__ ) );
define( 'BOOKLY_URL', plugins_url( '/', BOOKLY__FILE__ ) );
define( 'BOOKLY_PATH', plugin_dir_path( BOOKLY__FILE__ ) );
define( 'BOOKLY_ASSETS_URL', BOOKLY_URL . 'assets/' );

add_action( 'plugins_loaded', 'bookly_load_plugin_textdomain' );

if ( ! version_compare( PHP_VERSION, '5.4', '>=' ) ) {
	add_action( 'admin_notices', 'bookly_fail_php_version' );
} elseif ( ini_get( 'asp_tags' ) ) {
	add_action( 'admin_notices', 'bookly_fail_server_configuration_problem' );
} else {
	require( BOOKLY_PATH . 'includes/plugin.php' );
}

/**
 * Load gettext translate for our text domain.
 *
 * @since 1.0.0
 *
 * @return void
 */
function bookly_load_plugin_textdomain() {
	load_plugin_textdomain( 'bookly' );
}

/**
 * Show in WP Dashboard notice about the plugin is not activated.
 *
 * @since 1.0.0
 *
 * @return void
 */
function bookly_fail_php_version() {
	$message = esc_html__( 'Bookly requires PHP version 5.4+, plugin is currently NOT ACTIVE.', 'bookly' );
	$html_message = sprintf( '<div class="error">%s</div>', wpautop( $message ) );
	echo wp_kses_post( $html_message );
}

function bookly_fail_server_configuration_problem() {
	$message = esc_html__( 'Server Configuration Problem: asp_tags is enabled, but is not compatible with Bookly. You can disable `asp_tags` in `.htaccess` or `php.ini` file.', 'bookly' );
	$html_message = sprintf( '<div class="error">%s</div>', wpautop( $message ) );
	echo wp_kses_post( $html_message );
}
