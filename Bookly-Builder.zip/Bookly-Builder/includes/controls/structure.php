<?php
namespace Bookly;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Control_Structure extends Control_Base {

	public function get_type() {
		return 'structure';
	}

	public function content_template() {
		?>
		<div class="bookly-control-field">
			<div class="bookly-control-input-wrapper">
				<div class="bookly-control-structure-title"><?php _e( 'Structure', 'bookly' ); ?></div>
				<% var currentPreset = bookly.presetsFactory.getPresetByStructure( data.controlValue ); %>
				<div class="bookly-control-structure-preset bookly-control-structure-current-preset">
					<%= bookly.presetsFactory.getPresetSVG( currentPreset.preset, 233, 72, 5 ).outerHTML %>
				</div>
				<div class="bookly-control-structure-reset"><i class="fa fa-undo"></i><?php _e( 'Reset Structure', 'bookly' ); ?></div>
				<%
				var morePresets = getMorePresets();

				if ( morePresets.length > 1 ) { %>
					<div class="bookly-control-structure-more-presets-title"><?php _e( 'More Structures', 'bookly' ); ?></div>
					<div class="bookly-control-structure-more-presets">
						<% _.each( morePresets, function( preset ) { %>
							<div class="bookly-control-structure-preset-wrapper">
								<input id="bookly-control-structure-preset-<%- data._cid %>-<%- preset.key %>" type="radio" name="bookly-control-structure-preset-<%- data._cid %>" data-setting="structure" value="<%- preset.key %>">
								<label class="bookly-control-structure-preset" for="bookly-control-structure-preset-<%- data._cid %>-<%- preset.key %>">
									<%= bookly.presetsFactory.getPresetSVG( preset.preset, 102, 42 ).outerHTML %>
								</label>
								<div class="bookly-control-structure-preset-title"><%= preset.preset.join( ', ' ) %></div>
							</div>
						<% } ); %>
					</div>
				<% } %>
			</div>
		</div>
		
		<% if ( data.description ) { %>
			<div class="bookly-control-description"><%= data.description %></div>
		<% } %>
		<?php
	}

	protected function get_default_settings() {
		return [
			'separator' => 'none',
		];
	}
}
