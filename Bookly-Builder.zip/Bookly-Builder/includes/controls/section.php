<?php
namespace Bookly;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Control_Section extends Control_Base {

	public function get_type() {
		return 'section';
	}

	public function content_template() {
		?>
		<div class="bookly-panel-heading">
			<div class="bookly-panel-heading-toggle bookly-section-toggle" data-collapse_id="<% data.name %>">
				<i class="fa"></i>
			</div>
			<div class="bookly-panel-heading-title bookly-section-title"><%= data.label %></div>
		</div>
		<?php
	}

	protected function get_default_settings() {
		return [
			'separator' => 'none',
		];
	}
}
