<?php
namespace Bookly;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Control_Choose extends Control_Base {

	public function get_type() {
		return 'choose';
	}

	public function content_template() {
		?>
		<div class="bookly-control-field">
			<label class="bookly-control-title"><%= data.label %></label>
			<div class="bookly-control-input-wrapper">
				<div class="bookly-choices">
					<% _.each( data.options, function( options, value ) { %>
					<input id="bookly-choose-<%= data._cid + data.name + value %>" type="radio" name="bookly-choose-<%= data.name %>" value="<%= value %>">
					<label class="bookly-choices-label tooltip-target" for="bookly-choose-<%= data._cid + data.name + value %>" data-tooltip="<%= options.title %>" title="<%= options.title %>">
						<i class="fa fa-<%= options.icon %>"></i>
					</label>
					<% } ); %>
				</div>
			</div>
		</div>

		<% if ( data.description ) { %>
		<div class="bookly-control-description"><%= data.description %></div>
		<% } %>
		<?php
	}

	protected function get_default_settings() {
		return [
			'toggle' => true,
		];
	}
}
