<?php
namespace Bookly;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Control_Select2 extends Control_Base {

	public function get_type() {
		return 'select2';
	}

	public function content_template() {
		?>
		<div class="bookly-control-field">
			<label class="bookly-control-title"><%= data.label %></label>
			<div class="bookly-control-input-wrapper">
				<select class="bookly-select2" data-setting="<%= data.name %>">
					<% _.each( data.options, function( option_title, option_value ) { %>
					<option value="<%= option_value %>"><%= option_title %></option>
					<% } ); %>
				</select>
			</div>
		</div>
		<% if ( data.description ) { %>
		<div class="bookly-control-description"><%= data.description %></div>
		<% } %>
		<?php
	}
}
