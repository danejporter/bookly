<?php
namespace Bookly\System_Info\Classes;

use Bookly\System_Info\Classes\Abstracts\Base_Reporter;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class User_Reporter extends Base_Reporter {

	public function get_title() {
		return _x( 'User', 'System Info', 'bookly' );
	}

	public function get_fields() {
		return [
			'locale' => _x( 'WP Profile lang', 'System Info', 'bookly' ),
			'agent' => _x( 'User Agent', 'System Info', 'bookly' ),
		];
	}

	public function get_locale() {
		return [
			'value' => get_locale(),
		];
	}

	public function get_agent() {
		return [
			'value' => $_SERVER['HTTP_USER_AGENT'],
		];
	}
}
