<?php
namespace Bookly;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Element_Column extends Element_Base {

	public function get_id() {
		return 'column';
	}

	public function get_title() {
		return __( 'Column', 'bookly' );
	}

	public function get_icon() {
		return 'columns';
	}

	protected function _register_controls() {
		$this->add_control(
			'section_style',
			[
				'label' => __( 'Background & Border', 'bookly' ),
				'tab' => self::TAB_STYLE,
				'type' => Controls_Manager::SECTION,
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'background',
				'tab' => self::TAB_STYLE,
				'section' => 'section_style',
				'selector' => '{{WRAPPER}} > .bookly-element-populated',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'border',
				'tab' => self::TAB_STYLE,
				'section' => 'section_style',
				'selector' => '{{WRAPPER}} > .bookly-element-populated',
			]
		);

		$this->add_control(
			'border_radius',
			[
				'label' => __( 'Border Radius', 'bookly' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'tab' => self::TAB_STYLE,
				'section' => 'section_style',
				'selectors' => [
					'{{WRAPPER}} > .bookly-element-populated' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		// Section Typography
		$this->add_control(
			'section_typo',
			[
				'label' => __( 'Typography', 'bookly' ),
				'tab' => self::TAB_STYLE,
				'type' => Controls_Manager::SECTION,
			]
		);

		$this->add_control(
			'color_text',
			[
				'label' => __( 'Text Color', 'bookly' ),
				'type' => Controls_Manager::COLOR,
				'section' => 'section_typo',
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} > .bookly-element-populated' => 'color: {{VALUE}};',
				],
				'tab' => self::TAB_STYLE,
			]
		);

		$this->add_control(
			'heading_color',
			[
				'label' => __( 'Heading Color', 'bookly' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .bookly-element-populated .bookly-heading-title' => 'color: {{VALUE}};',
				],
				'tab' => self::TAB_STYLE,
				'section' => 'section_typo',
			]
		);

		$this->add_control(
			'color_link',
			[
				'label' => __( 'Link Color', 'bookly' ),
				'type' => Controls_Manager::COLOR,
				'section' => 'section_typo',
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .bookly-element-populated a' => 'color: {{VALUE}};',
				],
				'tab' => self::TAB_STYLE,
			]
		);

		$this->add_control(
			'color_link_hover',
			[
				'label' => __( 'Link Hover Color', 'bookly' ),
				'type' => Controls_Manager::COLOR,
				'section' => 'section_typo',
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .bookly-element-populated a:hover' => 'color: {{VALUE}};',
				],
				'tab' => self::TAB_STYLE,
			]
		);

		$this->add_control(
			'text_align',
			[
				'label' => __( 'Text Align', 'bookly' ),
				'type' => Controls_Manager::CHOOSE,
				'tab' => self::TAB_STYLE,
				'section' => 'section_typo',
				'options' => [
					'left' => [
						'title' => __( 'Left', 'bookly' ),
						'icon' => 'align-left',
					],
					'center' => [
						'title' => __( 'Center', 'bookly' ),
						'icon' => 'align-center',
					],
					'right' => [
						'title' => __( 'Right', 'bookly' ),
						'icon' => 'align-right',
					],
				],
				'selectors' => [
					'{{WRAPPER}} > .bookly-element-populated' => 'text-align: {{VALUE}};',
				],
			]
		);

		// Section Advanced
		$this->add_control(
			'section_advanced',
			[
				'label' => __( 'Advanced', 'bookly' ),
				'type' => Controls_Manager::SECTION,
				'tab' => self::TAB_ADVANCED,
			]
		);

		$this->add_control(
			'margin',
			[
				'label' => __( 'Margin', 'bookly' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'section' => 'section_advanced',
				'tab' => self::TAB_ADVANCED,
				'selectors' => [
					'{{WRAPPER}} > .bookly-element-populated' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'padding',
			[
				'label' => __( 'Padding', 'bookly' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'section' => 'section_advanced',
				'tab' => self::TAB_ADVANCED,
				'selectors' => [
					'{{WRAPPER}} > .bookly-element-populated' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'css_classes',
			[
				'label' => __( 'CSS Classes', 'bookly' ),
				'type' => Controls_Manager::TEXT,
				'section' => 'section_advanced',
				'tab' => self::TAB_ADVANCED,
				'default' => '',
				'prefix_class' => '',
			]
		);

		// Section Responsive
		$this->add_control(
			'section_responsive',
			[
				'label' => __( 'Responsive', 'bookly' ),
				'type' => Controls_Manager::SECTION,
				'tab' => self::TAB_ADVANCED,
			]
		);

		$responsive_points = [
			'screen_sm' => [
				'title' => __( 'Mobile Landscape', 'bookly' ),
				'class_prefix' => 'bookly-sm-',
			],
			'screen_xs' => [
				'title' => __( 'Mobile Portrait', 'bookly' ),
				'class_prefix' => 'bookly-xs-',
			],
		];

		foreach ( $responsive_points as $point_name => $point_data ) {
			$this->add_control(
				$point_name,
				[
					'label' => $point_data['title'],
					'type' => Controls_Manager::SELECT,
					'section' => 'section_responsive',
					'default' => 'default',
					'options' => [
						'default' => __( 'Default', 'bookly' ),
						'custom' => __( 'Custom', 'bookly' ),
					],
					'tab' => self::TAB_ADVANCED,
				]
			);

			$this->add_control(
				$point_name . '_width',
				[
					'label' => __( 'Column Width', 'bookly' ),
					'type' => Controls_Manager::SELECT,
					'section' => 'section_responsive',
					'options' => [
						'10' => '10%',
						'11' => '11%',
						'12' => '12%',
						'14' => '14%',
						'16' => '16%',
						'20' => '20%',
						'25' => '25%',
						'30' => '30%',
						'33' => '33%',
						'40' => '40%',
						'50' => '50%',
						'60' => '60%',
						'66' => '66%',
						'70' => '70%',
						'75' => '75%',
						'80' => '80%',
						'83' => '83%',
						'90' => '90%',
						'100' => '100%',
					],
					'default' => '100',
					'tab' => self::TAB_ADVANCED,
					'condition' => [
						$point_name => [ 'custom' ],
					],
					'prefix_class' => $point_data['class_prefix'],
				]
			);
		}
	}

	protected function render_settings() {
		?>
		<div class="bookly-element-overlay">
			<div class="column-title"></div>
			<div class="bookly-editor-element-settings bookly-editor-column-settings">
				<ul class="bookly-editor-element-settings-list bookly-editor-column-settings-list">
					<li class="bookly-editor-element-setting bookly-editor-element-trigger">
						<a href="#" title="<?php _e( 'Drag Column', 'bookly' ); ?>"><?php _e( 'Column', 'bookly' ); ?></a>
					</li>
					<?php /* Temp removing for better UI
					<li class="bookly-editor-element-setting bookly-editor-element-edit">
						<a href="#" title="<?php _e( 'Edit Column', 'bookly' ); ?>">
							<span class="bookly-screen-only"><?php _e( 'Edit', 'bookly' ); ?></span>
							<i class="fa fa-pencil"></i>
						</a>
					</li>
					*/ ?>
					<li class="bookly-editor-element-setting bookly-editor-element-duplicate">
						<a href="#" title="<?php _e( 'Duplicate Column', 'bookly' ); ?>">
							<span class="bookly-screen-only"><?php _e( 'Duplicate', 'bookly' ); ?></span>
							<i class="fa fa-files-o"></i>
						</a>
					</li>
					<li class="bookly-editor-element-setting bookly-editor-element-add">
						<a href="#" title="<?php _e( 'Add New Column', 'bookly' ); ?>">
							<span class="bookly-screen-only"><?php _e( 'Add', 'bookly' ); ?></span>
							<i class="fa fa-plus"></i>
						</a>
					</li>
					<li class="bookly-editor-element-setting bookly-editor-element-remove">
						<a href="#" title="<?php _e( 'Remove Column', 'bookly' ); ?>">
							<span class="bookly-screen-only"><?php _e( 'Remove', 'bookly' ); ?></span>
							<i class="fa fa-times"></i>
						</a>
					</li>
				</ul>
				<ul class="bookly-editor-element-settings-list  bookly-editor-section-settings-list">
					<li class="bookly-editor-element-setting bookly-editor-element-trigger">
						<a href="#" title="<?php _e( 'Drag Section', 'bookly' ); ?>"><?php _e( 'Section', 'bookly' ); ?></a>
					</li>
					<?php /* Temp removing for better UI
					<li class="bookly-editor-element-setting bookly-editor-element-edit">
						<a href="#" title="<?php _e( 'Edit', 'bookly' ); ?>">
							<span class="bookly-screen-only"><?php _e( 'Edit Section', 'bookly' ); ?></span>
							<i class="fa fa-pencil"></i>
						</a>
					</li>
					*/ ?>
					<li class="bookly-editor-element-setting bookly-editor-element-duplicate">
						<a href="#" title="<?php _e( 'Duplicate', 'bookly' ); ?>">
							<span class="bookly-screen-only"><?php _e( 'Duplicate Section', 'bookly' ); ?></span>
							<i class="fa fa-files-o"></i>
						</a>
					</li>
					<li class="bookly-editor-element-setting bookly-editor-element-remove">
						<a href="#" title="<?php _e( 'Remove', 'bookly' ); ?>">
							<span class="bookly-screen-only"><?php _e( 'Remove Section', 'bookly' ); ?></span>
							<i class="fa fa-times"></i>
						</a>
					</li>
				</ul>
			</div>
		</div>
		<?php
	}

	protected function content_template() {
		?>
		<div class="bookly-column-wrap">
			<div class="bookly-widget-wrap"></div>
		</div>
		<?php
	}

	public function before_render( $instance, $element_id, $element_data = [] ) {
		$wrapper_classes = [
			'bookly-column',
			'bookly-element',
			'bookly-element-' . $element_id,
			'bookly-col-' . $instance['_column_size'],
		];

		$column_type = ! empty( $element_data['isInner'] ) ? 'inner' : 'top';

		$wrapper_classes[] = 'bookly-' . $column_type . '-column';

		foreach ( $this->get_class_controls() as $control ) {
			if ( empty( $instance[ $control['name'] ] ) )
				continue;

			if ( ! $this->is_control_visible( $instance, $control ) )
				continue;

			$wrapper_classes[] = $control['prefix_class'] . $instance[ $control['name'] ];
		}

		if ( ! empty( $element_data['elements'] ) ) {

		}
		?>
		<div class="<?php echo esc_attr( implode( ' ', $wrapper_classes ) ); ?>" data-element_type="<?php echo $this->get_id(); ?>">
			<div class="bookly-column-wrap<?php if ( ! empty( $element_data['elements'] ) ) echo ' bookly-element-populated'; ?>">
				<div class="bookly-widget-wrap">
		<?php
	}

	public function after_render( $instance, $element_id, $element_data = [] ) {
		?>
				</div>
			</div>
		</div>
		<?php
	}
}
