<?php
namespace Bookly;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
?>
<script type="text/template" id="tmpl-bookly-panel-elements">
	<div id="bookly-panel-elements-search-area"></div>
	<div id="bookly-panel-elements-wrapper"></div>
</script>

<script type="text/template" id="tmpl-bookly-panel-elements-category">
	<div class="panel-elements-category-title"><%= title %></div>
	<div class="panel-elements-category-items"></div>
</script>

<script type="text/template" id="tmpl-bookly-panel-element-search">
	<input id="bookly-panel-elements-search-input" placeholder="<?php _e( 'Search Widget...', 'bookly' ); ?>" />
	<i class="fa fa-search"></i>
</script>

<script type="text/template" id="tmpl-bookly-element-library-element">
	<div class="bookly-element">
		<div class="icon">
			<i class="eicon-<%= icon %>"></i>
		</div>
		<div class="bookly-element-title-wrapper">
			<div class="title"><%= title %></div>
		</div>
	</div>
</script>
