<?php
namespace Bookly;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
?>
<script type="text/template" id="tmpl-bookly-empty-preview">
	<div class="bookly-first-add">
		<div class="bookly-icon eicon-plus"></div>
	</div>
</script>

<script type="text/template" id="tmpl-bookly-preview">
	<div id="bookly-section-wrap"></div>
	<div id="bookly-add-section" class="bookly-visible-desktop">
		<div id="bookly-add-section-inner">
			<div id="bookly-add-new-section">
				<button id="bookly-add-section-button" class="bookly-button"><?php _e( 'Add New Section', 'bookly' ); ?></button>
				<div id="bookly-add-section-drag-title"><?php _e( 'Or drag widget here', 'bookly' ); ?></div>
			</div>
			<div id="bookly-select-preset">
				<div id="bookly-select-preset-close">
					<i class="fa fa-times"></i>
				</div>
				<div id="bookly-select-preset-title"><?php _e( 'SELECT YOUR STRUCTURE', 'bookly' ); ?></div>
				<ul id="bookly-select-preset-list">
					<%
					var structures = [ 10, 20, 30, 40, 21, 22, 31, 32, 33, 50, 60, 34 ];

					_.each( structures, function( structure ) {
						var preset = bookly.presetsFactory.getPresetByStructure( structure ); %>

						<li class="bookly-preset bookly-column bookly-col-16" data-structure="<%- structure %>">
							<%= bookly.presetsFactory.getPresetSVG( preset.preset ).outerHTML %>
						</li>
					<% } ); %>
				</ul>
			</div>
		</div>
	</div>
</script>
