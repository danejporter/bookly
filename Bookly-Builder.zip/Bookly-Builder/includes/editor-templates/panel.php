<?php
namespace Bookly;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
?>
<script type="text/template" id="tmpl-bookly-panel">
	<div id="bookly-mode-switcher"></div>
	<header id="bookly-panel-header-wrapper"></header>
	<main id="bookly-panel-content-wrapper"></main>
	<footer id="bookly-panel-footer">
		<div class="bookly-panel-container">
		</div>
	</footer>
</script>

<script type="text/template" id="tmpl-bookly-panel-menu-item">
	<div class="bookly-panel-menu-item-icon">
		<i class="fa fa-<%= icon %>"></i>
	</div>
	<div class="bookly-panel-menu-item-title"><%= title %></div>
</script>

<script type="text/template" id="tmpl-bookly-panel-header">
	<div id="bookly-panel-header-menu-button" class="bookly-header-button">
		<i class="bookly-icon eicon-menu tooltip-target" data-tooltip="<?php esc_attr_e( 'Menu', 'bookly' ); ?>"></i>
	</div>
	<div id="bookly-panel-header-title"></div>
	<div id="bookly-panel-header-add-button" class="bookly-header-button">
		<i class="bookly-icon eicon-apps tooltip-target" data-tooltip="<?php esc_attr_e( 'Widgets Panel', 'bookly' ); ?>"></i>
	</div>
</script>

<script type="text/template" id="tmpl-bookly-panel-footer-content">
	<div id="bookly-panel-footer-exit" class="bookly-panel-footer-tool" title="<?php _e( 'Exit', 'bookly' ); ?>">
		<i class="fa fa-times"></i>
		<div class="bookly-panel-footer-sub-menu-wrapper">
			<div class="bookly-panel-footer-sub-menu">
				<a id="bookly-panel-footer-view-page" class="bookly-panel-footer-sub-menu-item" href="<?php the_permalink(); ?>" target="_blank">
					<i class="bookly-icon fa fa-external-link"></i>
					<span class="bookly-title"><?php _e( 'View Page', 'bookly' ); ?></span>
				</a>
				
			</div>
		</div>
	</div>
	<div id="bookly-panel-footer-responsive" class="bookly-panel-footer-tool" title="<?php esc_attr_e( 'Responsive Mode', 'bookly' ); ?>">
		<i class="fa fa-desktop"></i>
		<div class="bookly-panel-footer-sub-menu-wrapper">
			<div class="bookly-panel-footer-sub-menu">
				<div class="bookly-panel-footer-sub-menu-item" data-device-mode="desktop">
					<i class="bookly-icon fa fa-desktop"></i>
					<span class="bookly-title"><?php _e( 'Desktop', 'bookly' ); ?></span>
					<span class="bookly-description"><?php _e( '1024px > Up', 'bookly' ); ?></span>
				</div>
				<div class="bookly-panel-footer-sub-menu-item" data-device-mode="laptop">
					<i class="bookly-icon fa fa-laptop"></i>
					<span class="bookly-title"><?php _e( 'Laptop', 'bookly' ); ?></span>
					<span class="bookly-description"><?php _e( '1024px > 768px', 'bookly' ); ?></span>
				</div>
				<div class="bookly-panel-footer-sub-menu-item" data-device-mode="tablet">
					<i class="bookly-icon fa fa-tablet"></i>
					<span class="bookly-title"><?php _e( 'Tablet', 'bookly' ); ?></span>
					<span class="bookly-description"><?php _e( '768px > 1024px', 'bookly' ); ?></span>
				</div>
				<div class="bookly-panel-footer-sub-menu-item" data-device-mode="mobile-landscape">
					<i class="bookly-icon fa fa-mobile"></i>
					<span class="bookly-title"><?php _e( 'Mobile Landscape', 'bookly' ); ?></span>
					<span class="bookly-description"><?php _e( '767px > Down', 'bookly' ); ?></span>
				</div>
				<div class="bookly-panel-footer-sub-menu-item" data-device-mode="mobile">
					<i class="bookly-icon fa fa-mobile"></i>
					<span class="bookly-title"><?php _e( 'Mobile Portrait', 'bookly' ); ?></span>
					<span class="bookly-description"><?php _e( '479px > Down', 'bookly' ); ?></span>
				</div>
			</div>
		</div>
	</div>
	<div id="bookly-panel-footer-help" class="bookly-panel-footer-tool" title="<?php esc_attr_e( 'Help', 'bookly' ); ?>">
		<span class="bookly-screen-only"><?php _e( 'Help', 'bookly' ); ?></span>
		<i class="fa fa-question-circle"></i>
		<div class="bookly-panel-footer-sub-menu-wrapper">
			<div class="bookly-panel-footer-sub-menu">
				<div id="bookly-panel-footer-help-title"><?php _e( 'Need help?', 'bookly' ); ?></div>
				<div id="bookly-panel-footer-watch-tutorial" class="bookly-panel-footer-sub-menu-item">
					<i class="bookly-icon fa fa-video-camera"></i>
					<span class="bookly-title"><?php _e( 'Take a tour', 'bookly' ); ?></span>
				</div>
				<div class="bookly-panel-footer-sub-menu-item">
					<i class="bookly-icon fa fa-external-link"></i>
					<a class="bookly-title" href="https://go.bookly.com/docs" target="_blank"><?php _e( 'Go to the Documentation', 'bookly' ); ?></a>
				</div>
			</div>
		</div>
	</div>
	<div id="bookly-panel-footer-save" class="bookly-panel-footer-tool" title="<?php esc_attr_e( 'Save', 'bookly' ); ?>">
		<button class="bookly-button">
			<span class="bookly-state-icon">
				<i class="fa fa-spin fa-circle-o-notch "></i>
			</span>
			<?php _e( 'Save', 'bookly' ); ?>
		</button>
		<?php /*<div class="bookly-panel-footer-sub-menu-wrapper">
			<div class="bookly-panel-footer-sub-menu">
				<div id="bookly-panel-footer-publish" class="bookly-panel-footer-sub-menu-item">
					<i class="bookly-icon fa fa-check-circle"></i>
					<span class="bookly-title"><?php _e( 'Publish', 'bookly' ); ?></span>
				</div>
				<div id="bookly-panel-footer-discard" class="bookly-panel-footer-sub-menu-item">
					<i class="bookly-icon fa fa-times-circle"></i>
					<span class="bookly-title"><?php _e( 'Discard', 'bookly' ); ?></span>
				</div>
			</div>
		</div>*/ ?>
	</div>
</script>

<script type="text/template" id="tmpl-bookly-mode-switcher-content">
	<input id="bookly-mode-switcher-preview-input" type="checkbox">
	<label for="bookly-mode-switcher-preview-input" id="bookly-mode-switcher-preview" title="<?php esc_attr_e( 'Preview', 'bookly' ); ?>">
		<span class="bookly-screen-only"><?php _e( 'Preview', 'bookly' ); ?></span>
		<i class="fa"></i>
	</label>
</script>

<script type="text/template" id="tmpl-editor-content">
	<div class="bookly-tabs-controls">
		<ul>
			<% _.each( elementData.tabs_controls, function( tabTitle, tabSlug ) { %>
			<li class="bookly-tab-control-<%- tabSlug %>">
				<a href="#" data-tab="<%= tabSlug %>">
					<%= tabTitle %>
				</a>
			</li>
			<% } ); %>
		</ul>
	</div>
	<div class="bookly-controls"></div>
</script>

<script type="text/template" id="tmpl-bookly-panel-schemes-typography">
	<div class="bookly-panel-scheme-buttons">
		<div class="bookly-panel-scheme-button-wrapper bookly-panel-scheme-reset">
			<button class="bookly-button">
				<i class="fa fa-undo"></i>
				<?php _e( 'Reset', 'bookly' ); ?>
			</button>
		</div>
		<div class="bookly-panel-scheme-button-wrapper bookly-panel-scheme-discard">
			<button class="bookly-button">
				<i class="fa fa-times"></i>
				<?php _e( 'Discard', 'bookly' ); ?>
			</button>
		</div>
		<div class="bookly-panel-scheme-button-wrapper bookly-panel-scheme-save">
			<button class="bookly-button bookly-button-success" disabled><?php _e( 'Apply', 'bookly' ); ?></button>
		</div>
	</div>
	<div class="bookly-panel-scheme-items"></div>
</script>

<script type="text/template" id="tmpl-bookly-panel-schemes-colors">
	<div class="bookly-panel-scheme-buttons">
		<div class="bookly-panel-scheme-button-wrapper bookly-panel-scheme-reset">
			<button class="bookly-button">
				<i class="fa fa-undo"></i>
				<?php _e( 'Reset', 'bookly' ); ?>
			</button>
		</div>
		<div class="bookly-panel-scheme-button-wrapper bookly-panel-scheme-discard">
			<button class="bookly-button">
				<i class="fa fa-times"></i>
				<?php _e( 'Discard', 'bookly' ); ?>
			</button>
		</div>
		<div class="bookly-panel-scheme-button-wrapper bookly-panel-scheme-save">
			<button class="bookly-button bookly-button-success" disabled><?php _e( 'Apply', 'bookly' ); ?></button>
		</div>
	</div>
	<div class="bookly-panel-scheme-content bookly-panel-box">
		<div class="bookly-panel-heading">
			<div class="bookly-panel-heading-title"><?php _e( 'Color Palette', 'bookly' ); ?></div>
		</div>
		<div class="bookly-panel-scheme-items bookly-panel-box-content"></div>
	</div>
	<div class="bookly-panel-scheme-colors-more-palettes bookly-panel-box">
		<div class="bookly-panel-heading">
			<div class="bookly-panel-heading-title"><?php _e( 'More Palettes', 'bookly' ); ?></div>
		</div>
		<div class="bookly-panel-box-content">
			<?php foreach ( Scheme_Color::get_system_schemes() as $scheme_name => $scheme ) : ?>
				<div class="bookly-panel-scheme-color-system-scheme" data-scheme-name="<?php echo $scheme_name; ?>">
					<div class="bookly-panel-scheme-color-system-items">
						<?php
						$print_colors_index = [
							Scheme_Color::COLOR_1,
							Scheme_Color::COLOR_2,
							Scheme_Color::COLOR_3,
							Scheme_Color::COLOR_4,
						];
						$colors_to_print = [];
						foreach ( $print_colors_index as $color_name ) {
							$colors_to_print[ $color_name ] = $scheme['items'][ $color_name ];
						}

						foreach ( $colors_to_print as $color_value ) : ?>
							<div class="bookly-panel-scheme-color-system-item" style="background-color: <?php echo esc_attr( $color_value ); ?>;"></div>
						<?php endforeach; ?>
					</div>
					<div class="bookly-title"><?php echo $scheme['title']; ?></div>
				</div>
			<?php endforeach; ?>
		</div>
	</div>
</script>

<script type="text/template" id="tmpl-bookly-panel-scheme-color-item">
	<div class="bookly-panel-scheme-color-input-wrapper">
		<input type="text" class="bookly-panel-scheme-color-value" value="<%= value %>" />
	</div>
	<div class="bookly-panel-scheme-color-title"><%= title %></div>
</script>

<script type="text/template" id="tmpl-bookly-panel-scheme-typography-item">
	<div class="bookly-panel-heading">
		<div class="bookly-panel-heading-toggle">
			<i class="fa"></i>
		</div>
		<div class="bookly-panel-heading-title"><%= title %></div>
	</div>
	<div class="bookly-panel-scheme-typography-items bookly-panel-box-content">
		<?php
		$scheme_fields_keys = Group_Control_Typography::get_scheme_fields_keys();

		$typography_fields = Group_Control_Typography::get_fields();

		$scheme_fields = array_intersect_key( $typography_fields, array_flip( $scheme_fields_keys ) );

		foreach ( $scheme_fields as $option_name => $option ) : ?>
			<div class="bookly-panel-scheme-typography-item">
				<div class="bookly-panel-scheme-item-title bookly-control-title"><?php echo $option['label']; ?></div>
				<div class="bookly-panel-scheme-typography-item-value">
					<?php if ( 'select' === $option['type'] ) : ?>
						<select name="<?php echo $option_name; ?>" class="bookly-panel-scheme-typography-item-field">
							<?php foreach ( $option['options'] as $field_key => $field_value ) : ?>
								<option value="<?php echo $field_key; ?>"><?php echo $field_value; ?></option>
							<?php endforeach; ?>
						</select>
					<?php elseif ( 'font' === $option['type'] ) : ?>
						<select name="<?php echo $option_name; ?>" class="bookly-panel-scheme-typography-item-field">
							<option value=""><?php _e( 'Default', 'bookly' ); ?></option>

							<optgroup label="<?php _e( 'System', 'bookly' ); ?>">
								<?php foreach ( Fonts::get_fonts_by_groups( [ Fonts::SYSTEM ] ) as $font_title => $font_type ) : ?>
									<option value="<?php echo esc_attr( $font_title ); ?>"><?php echo $font_title; ?></option>
								<?php endforeach; ?>
							</optgroup>

							<optgroup label="<?php _e( 'Google', 'bookly' ); ?>">
								<?php foreach ( Fonts::get_fonts_by_groups( [ Fonts::GOOGLE, Fonts::EARLYACCESS ] ) as $font_title => $font_type ) : ?>
									<option value="<?php echo esc_attr( $font_title ); ?>"><?php echo $font_title; ?></option>
								<?php endforeach; ?>
							</optgroup>
						</select>
					<?php elseif ( 'text' === $option['type'] ) : ?>
						<input name="<?php echo $option_name; ?>" class="bookly-panel-scheme-typography-item-field" />
					<?php endif; ?>
				</div>
			</div>
		<?php endforeach; ?>
	</div>
</script>
