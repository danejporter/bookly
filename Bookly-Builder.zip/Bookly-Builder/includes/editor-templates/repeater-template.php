<?php
namespace Bookly;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

?>
<script type="text/template" id="tmpl-bookly-repeater-row">
	<div class="bookly-repeater-row-tools">
		<div class="bookly-repeater-row-handle-sortable">
			<i class="fa fa-ellipsis-v"></i>
		</div>
		<div class="bookly-repeater-row-item-title"></div>
		<div class="bookly-repeater-row-tool bookly-repeater-tool-duplicate">
			<i class="fa fa-copy"></i>
		</div>
		<div class="bookly-repeater-row-tool bookly-repeater-tool-remove">
			<i class="fa fa-remove"></i>
		</div>
	</div>
	<div class="bookly-repeater-row-controls"></div>
</script>
