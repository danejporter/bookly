<?php
namespace Bookly;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Widget_Testimonial extends Widget_Base {

	public function get_id() {
		return 'testimonial';
	}

	public function get_title() {
		return __( 'Testimonial', 'bookly' );
	}

	public function get_icon() {
		return 'testimonial';
	}

	protected function _register_controls() {
		$this->add_control(
			'section_testimonial',
			[
				'label' => __( 'Testimonial', 'bookly' ),
				'type' => Controls_Manager::SECTION,
			]
		);

		$this->add_control(
			'testimonial_content',
			[
				'label' => __( 'Content', 'bookly' ),
				'type' => Controls_Manager::TEXTAREA,
				'rows' => '10',
				'default' => 'Click edit button to change this text. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.',
				'label_block' => true,
				'section' => 'section_testimonial',
			]
		);

		$this->add_control(
			'testimonial_image',
			[
				'label' => __( 'Add Image', 'bookly' ),
				'type' => Controls_Manager::MEDIA,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
				'section' => 'section_testimonial',
			]
		);

		$this->add_control(
			'testimonial_name',
			[
				'label' => __( 'Name', 'bookly' ),
				'type' => Controls_Manager::TEXT,
				'default' => 'John Doe',
				'section' => 'section_testimonial',
			]
		);

		$this->add_control(
			'testimonial_job',
			[
				'label' => __( 'Job', 'bookly' ),
				'type' => Controls_Manager::TEXT,
				'default' => 'Designer',
				'section' => 'section_testimonial',
			]
		);

		$this->add_control(
			'testimonial_image_position',
			[
				'label' => __( 'Image Position', 'bookly' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'aside',
				'section' => 'section_testimonial',
				'options' => [
					'aside' => __( 'Aside', 'bookly' ),
					'top' => __( 'Top', 'bookly' ),
				],
				'condition' => [
					'testimonial_image[url]!' => '',
				],
			]
		);

		$this->add_control(
			'testimonial_alignment',
			[
				'label' => __( 'Alignment', 'bookly' ),
				'type' => Controls_Manager::CHOOSE,
				'default' => 'center',
				'section' => 'section_testimonial',
				'options' => [
					'left'    => [
						'title' => __( 'Left', 'bookly' ),
						'icon' => 'align-left',
					],
					'center' => [
						'title' => __( 'Center', 'bookly' ),
						'icon' => 'align-center',
					],
					'right' => [
						'title' => __( 'Right', 'bookly' ),
						'icon' => 'align-right',
					],
				],
			]
		);

		$this->add_control(
			'view',
			[
				'label' => __( 'View', 'bookly' ),
				'type' => Controls_Manager::HIDDEN,
				'default' => 'traditional',
				'section' => 'section_image_carousel',
			]
		);

		// Content
		$this->add_control(
			'section_style_testimonial_content',
			[
				'label' => __( 'Content', 'bookly' ),
				'type' => Controls_Manager::SECTION,
				'tab' => self::TAB_STYLE,
			]
		);

		$this->add_control(
			'content_content_color',
			[
				'label' => __( 'Content Color', 'bookly' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_3,
				],
				'tab' => self::TAB_STYLE,
				'section' => 'section_style_testimonial_content',
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .bookly-testimonial-content' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'content_typography',
				'label' => __( 'Typography', 'bookly' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_3,
				'tab' => self::TAB_STYLE,
				'section' => 'section_style_testimonial_content',
				'selector' => '{{WRAPPER}} .bookly-testimonial-content',
			]
		);

		// Image
		$this->add_control(
			'section_style_testimonial_image',
			[
				'label' => __( 'Image', 'bookly' ),
				'type' => Controls_Manager::SECTION,
				'tab' => self::TAB_STYLE,
				'condition' => [
					'testimonial_image[url]!' => '',
				],
			]
		);

		$this->add_control(
			'image_size',
			[
				'label' => __( 'Image Size', 'bookly' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 20,
						'max' => 200,
					],
				],
				'section' => 'section_style_testimonial_image',
				'tab' => self::TAB_STYLE,
				'selectors' => [
					'{{WRAPPER}} .bookly-testimonial-wrapper .bookly-testimonial-image img' => 'width: {{SIZE}}{{UNIT}};height: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'testimonial_image[url]!' => '',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'image_border',
				'tab' => self::TAB_STYLE,
				'section' => 'section_style_testimonial_image',
				'selector' => '{{WRAPPER}} .bookly-testimonial-wrapper .bookly-testimonial-image img',
				'condition' => [
					'testimonial_image[url]!' => '',
				],
			]
		);

		$this->add_control(
			'image_border_radius',
			[
				'label' => __( 'Border Radius', 'bookly' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'tab' => self::TAB_STYLE,
				'section' => 'section_style_testimonial_image',
				'selectors' => [
					'{{WRAPPER}} .bookly-testimonial-wrapper .bookly-testimonial-image img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'testimonial_image[url]!' => '',
				],
			]
		);

		// Name
		$this->add_control(
			'section_style_testimonial_name',
			[
				'label' => __( 'Name', 'bookly' ),
				'type' => Controls_Manager::SECTION,
				'tab' => self::TAB_STYLE,
			]
		);

		$this->add_control(
			'name_text_color',
			[
				'label' => __( 'Text Color', 'bookly' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
				'tab' => self::TAB_STYLE,
				'section' => 'section_style_testimonial_name',
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .bookly-testimonial-name' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'name_typography',
				'label' => __( 'Typography', 'bookly' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'tab' => self::TAB_STYLE,
				'section' => 'section_style_testimonial_name',
				'selector' => '{{WRAPPER}} .bookly-testimonial-name',
			]
		);

		// Job
		$this->add_control(
			'section_style_testimonial_job',
			[
				'label' => __( 'Job', 'bookly' ),
				'type' => Controls_Manager::SECTION,
				'tab' => self::TAB_STYLE,
			]
		);

		$this->add_control(
			'job_text_color',
			[
				'label' => __( 'Text Color', 'bookly' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_2,
				],
				'tab' => self::TAB_STYLE,
				'section' => 'section_style_testimonial_job',
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .bookly-testimonial-job' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'job_typography',
				'label' => __( 'Typography', 'bookly' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_2,
				'tab' => self::TAB_STYLE,
				'section' => 'section_style_testimonial_job',
				'selector' => '{{WRAPPER}} .bookly-testimonial-job',
			]
		);
	}

	protected function render( $instance = [] ) {
		if ( empty( $instance['testimonial_name'] ) || empty( $instance['testimonial_content'] ) )
			return;

		$has_image = false;
		if ( '' !== $instance['testimonial_image']['url'] ) {
			$image_url = $instance['testimonial_image']['url'];
			$has_image = ' bookly-has-image';
		}

		$testimonial_alignment = $instance['testimonial_alignment'] ? ' bookly-testimonial-text-align-' . $instance['testimonial_alignment'] : '';
		$testimonial_image_position = $instance['testimonial_image_position'] ? ' bookly-testimonial-image-position-' . $instance['testimonial_image_position'] : '';
		?>
		<div class="bookly-testimonial-wrapper<?php echo $testimonial_alignment; ?>">

			<?php if ( ! empty( $instance['testimonial_content'] ) ) : ?>
				<div class="bookly-testimonial-content">
						<?php echo $instance['testimonial_content']; ?>
				</div>
			<?php endif; ?>

			<div class="bookly-testimonial-meta<?php if ( $has_image ) echo $has_image; ?><?php echo $testimonial_image_position; ?>">
				<div class="bookly-testimonial-meta-inner">
					<?php if ( isset( $image_url ) ) : ?>
						<div class="bookly-testimonial-image">
							<img src="<?php echo esc_attr( $image_url ); ?>" alt="<?php echo esc_attr( $this->get_image_alt( $instance ) ); ?>" />
						</div>
					<?php endif; ?>

					<div class="bookly-testimonial-details">
						<?php if ( ! empty( $instance['testimonial_name'] ) ) : ?>
							<div class="bookly-testimonial-name">
								<?php echo $instance['testimonial_name']; ?>
							</div>
						<?php endif; ?>

						<?php if ( ! empty( $instance['testimonial_job'] ) ) : ?>
							<div class="bookly-testimonial-job">
								<?php echo $instance['testimonial_job']; ?>
							</div>
						<?php endif; ?>
					</div>
				</div>
			</div>
		</div>
	<?php
	}

	protected function content_template() {
		?>
		<%
		var imageUrl = false, hasImage = '';
		if ( '' !== settings.testimonial_image.url ) {
			imageUrl = settings.testimonial_image.url;
			hasImage = ' bookly-has-image';
		}

		var testimonial_alignment = settings.testimonial_alignment ? ' bookly-testimonial-text-align-' + settings.testimonial_alignment : '';
		var testimonial_image_position = settings.testimonial_image_position ? ' bookly-testimonial-image-position-' + settings.testimonial_image_position : '';
		%>
		<div class="bookly-testimonial-wrapper<%- testimonial_alignment %>">

			<% if ( '' !== settings.testimonial_content ) { %>
				<div class="bookly-testimonial-content">
					<%= settings.testimonial_content %>
				</div>
		    <% } %>

			<div class="bookly-testimonial-meta<%- hasImage %><%- testimonial_image_position %>">
				<div class="bookly-testimonial-meta-inner">
					<% if ( imageUrl ) { %>
					<div class="bookly-testimonial-image">
						<img src="<%- imageUrl %>" alt="testimonial" />
					</div>
					<% } %>

					<div class="bookly-testimonial-details">

						<% if ( '' !== settings.testimonial_name ) { %>
						<div class="bookly-testimonial-name">
							<%= settings.testimonial_name %>
						</div>
						<% } %>

						<% if ( '' !== settings.testimonial_job ) { %>
						<div class="bookly-testimonial-job">
							<%= settings.testimonial_job %>
						</div>
						<% } %>

					</div>
				</div>
			</div>
		</div>
	<?php
	}

	private function get_image_alt( $instance ) {
		$post_id = $instance['testimonial_image']['id'];

		if ( ! $post_id ) {
			return false;
		}

		$alt = get_post_meta( $post_id, '_wp_attachment_image_alt', true );
		if ( ! $alt ) {
			$attachment = get_post( $post_id );
			$alt = $attachment->post_excerpt;
			if ( ! $alt ) {
				$alt = $attachment->post_title;
			}
		}
		return trim( strip_tags( $alt ) );
	}
}
