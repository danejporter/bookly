<?php
namespace Bookly;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Widget_Icon extends Widget_Base {

	public function get_id() {
		return 'icon';
	}

	public function get_title() {
		return __( 'Icon', 'bookly' );
	}

	public function get_icon() {
		return 'favorite';
	}

	protected function _register_controls() {
		$this->add_control(
			'section_icon',
			[
				'label' => __( 'Icon', 'bookly' ),
				'type' => Controls_Manager::SECTION,
			]
		);

		$this->add_control(
			'view',
			[
				'label' => __( 'View', 'bookly' ),
				'type' => Controls_Manager::SELECT,
				'section' => 'section_icon',
				'options' => [
					'default' => __( 'Default', 'bookly' ),
					'stacked' => __( 'Stacked', 'bookly' ),
					'framed' => __( 'Framed', 'bookly' ),
				],
				'default' => 'default',
				'prefix_class' => 'bookly-view-',
			]
		);

		$this->add_control(
			'icon',
			[
				'label' => __( 'Icon', 'bookly' ),
				'type' => Controls_Manager::ICON,
				'label_block' => true,
				'default' => 'fa fa-bullhorn',
				'section' => 'section_icon',
			]
		);

		$this->add_control(
			'shape',
			[
				'label' => __( 'Shape', 'bookly' ),
				'type' => Controls_Manager::SELECT,
				'section' => 'section_icon',
				'options' => [
					'circle' => __( 'Circle', 'bookly' ),
					'square' => __( 'Square', 'bookly' ),
				],
				'default' => 'circle',
				'condition' => [
					'view!' => 'default',
				],
				'prefix_class' => 'bookly-shape-',
			]
		);

		$this->add_control(
			'link',
			[
				'label' => __( 'Link', 'bookly' ),
				'type' => Controls_Manager::URL,
				'placeholder' => 'http://your-link.com',
				'section' => 'section_icon',
			]
		);

		$this->add_control(
			'align',
			[
				'label' => __( 'Alignment', 'bookly' ),
				'type' => Controls_Manager::CHOOSE,
				'section' => 'section_icon',
				'options' => [
					'left'    => [
						'title' => __( 'Left', 'bookly' ),
						'icon' => 'align-left',
					],
					'center' => [
						'title' => __( 'Center', 'bookly' ),
						'icon' => 'align-center',
					],
					'right' => [
						'title' => __( 'Right', 'bookly' ),
						'icon' => 'align-right',
					],
				],
				'default' => 'center',
				'prefix_class' => 'bookly-align-',
			]
		);

		$this->add_control(
			'section_style_icon',
			[
				'label' => __( 'Icon', 'bookly' ),
				'type' => Controls_Manager::SECTION,
				'tab' => self::TAB_STYLE,
			]
		);

		$this->add_control(
			'primary_color',
			[
				'label' => __( 'Primary Color', 'bookly' ),
				'type' => Controls_Manager::COLOR,
				'tab' => self::TAB_STYLE,
				'section' => 'section_style_icon',
				'default' => '',
				'selectors' => [
					'{{WRAPPER}}.bookly-view-stacked .bookly-icon' => 'background-color: {{VALUE}};',
					'{{WRAPPER}}.bookly-view-framed .bookly-icon, {{WRAPPER}}.bookly-view-default .bookly-icon' => 'color: {{VALUE}}; border-color: {{VALUE}};',
				],
				'alpha' => true,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
			]
		);

		$this->add_control(
			'secondary_color',
			[
				'label' => __( 'Secondary Color', 'bookly' ),
				'type' => Controls_Manager::COLOR,
				'tab' => self::TAB_STYLE,
				'section' => 'section_style_icon',
				'default' => '',
				'condition' => [
					'view!' => 'default',
				],
				'selectors' => [
					'{{WRAPPER}}.bookly-view-framed .bookly-icon' => 'background-color: {{VALUE}};',
					'{{WRAPPER}}.bookly-view-stacked .bookly-icon' => 'color: {{VALUE}};',
				],
				'alpha' => true,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_2,
				],
			]
		);

		$this->add_control(
			'size',
			[
				'label' => __( 'Icon Size', 'bookly' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 6,
						'max' => 300,
					],
				],
				'tab' => self::TAB_STYLE,
				'section' => 'section_style_icon',
				'selectors' => [
					'{{WRAPPER}} .bookly-icon i' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'icon_padding',
			[
				'label' => __( 'Icon Padding', 'bookly' ),
				'type' => Controls_Manager::SLIDER,
				'tab' => self::TAB_STYLE,
				'section' => 'section_style_icon',
				'selectors' => [
					'{{WRAPPER}} .bookly-icon' => 'padding: {{SIZE}}{{UNIT}};',
				],
				'default' => [
					'size' => 1.5,
					'unit' => 'em',
				],
				'range' => [
					'em' => [
						'min' => 0,
					],
				],
				'condition' => [
					'view!' => 'default',
				],
			]
		);

		$this->add_control(
			'rotate',
			[
				'label' => __( 'Icon Rotate', 'bookly' ),
				'type' => Controls_Manager::SLIDER,
				'default' => [
					'size' => 0,
					'unit' => 'deg',
				],
				'tab' => self::TAB_STYLE,
				'section' => 'section_style_icon',
				'selectors' => [
					'{{WRAPPER}} .bookly-icon i' => 'transform: rotate({{SIZE}}{{UNIT}});',
				],
			]
		);

		$this->add_control(
			'border_width',
			[
				'label' => __( 'Border Width', 'bookly' ),
				'type' => Controls_Manager::DIMENSIONS,
				'tab' => self::TAB_STYLE,
				'section' => 'section_style_icon',
				'selectors' => [
					'{{WRAPPER}} .bookly-icon' => 'border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'view' => 'framed',
				],
			]
		);

		/* TEMP - border color come from primary color
		$this->add_control(
			'border_color',
			[
				'label' => __( 'Border Color', 'bookly' ),
				'type' => Controls_Manager::COLOR,
				'tab' => self::TAB_STYLE,
				'section' => 'section_style_icon',
				'selectors' => [
					'{{WRAPPER}} .bookly-icon' => 'border-color: {{VALUE}};',
				],
				'condition' => [
					'view' => 'framed',
				],
			]
		);
		*/

		$this->add_control(
			'border_radius',
			[
				'label' => __( 'Border Radius', 'bookly' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'tab' => self::TAB_STYLE,
				'section' => 'section_style_icon',
				'selectors' => [
					'{{WRAPPER}} .bookly-icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'view!' => 'default',
				],
			]
		);

		$this->add_control(
			'section_hover',
			[
				'label' => __( 'Icon Hover', 'bookly' ),
				'type' => Controls_Manager::SECTION,
				'tab' => self::TAB_STYLE,
			]
		);

		$this->add_control(
			'hover_primary_color',
			[
				'label' => __( 'Primary Color', 'bookly' ),
				'type' => Controls_Manager::COLOR,
				'tab' => self::TAB_STYLE,
				'section' => 'section_hover',
				'default' => '',
				'selectors' => [
					'{{WRAPPER}}.bookly-view-stacked .bookly-icon:hover' => 'background-color: {{VALUE}};',
					'{{WRAPPER}}.bookly-view-framed .bookly-icon:hover, {{WRAPPER}}.bookly-view-default .bookly-icon:hover' => 'color: {{VALUE}}; border-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'hover_secondary_color',
			[
				'label' => __( 'Secondary Color', 'bookly' ),
				'type' => Controls_Manager::COLOR,
				'tab' => self::TAB_STYLE,
				'section' => 'section_hover',
				'default' => '',
				'condition' => [
					'view!' => 'default',
				],
				'selectors' => [
					'{{WRAPPER}}.bookly-view-framed .bookly-icon:hover' => 'background-color: {{VALUE}};',
					'{{WRAPPER}}.bookly-view-stacked .bookly-icon:hover' => 'color: {{VALUE}};',
				],
			]
		);
	}

	protected function render( $instance = [] ) {
		$this->add_render_attribute( 'wrapper', 'class', 'bookly-icon-wrapper' );

		$this->add_render_attribute( 'icon-wrapper', 'class', 'bookly-icon' );

		if ( ! empty( $instance['icon'] ) ) {
			$this->add_render_attribute( 'icon', 'class', $instance['icon'] );
		}

		if ( ! empty( $instance['link']['url'] ) ) {
			$this->add_render_attribute( 'link', 'href', $instance['link']['url'] );

			if ( ! empty( $instance['link']['is_external'] ) ) {
				$this->add_render_attribute( 'link', 'target', '_blank' );
			}
		}
		?>
		<div <?php echo $this->get_render_attribute_string( 'wrapper' ); ?>>
			<?php if ( ! empty( $instance['icon'] ) ) : ?>
				<?php if ( ! empty( $instance['link']['url'] ) ) : ?>
					<a <?php echo $this->get_render_attribute_string( 'link' ); ?>>
				<?php endif;?>
					<div <?php echo $this->get_render_attribute_string( 'icon-wrapper' ); ?>>
						<i <?php echo $this->get_render_attribute_string( 'icon' ); ?>></i>
					</div>
				<?php if ( ! empty( $instance['link']['url'] ) ) : ?>
					</a>
				<?php endif; ?>
			<?php endif; ?>
		</div>
		<?php
	}

	protected function content_template() {
		?>
		<div class="bookly-icon-wrapper">
			<% if ( settings.icon ) {
			var hasLink = settings.link && settings.link.url;
			%>
			<% if ( hasLink ) { %>
			<a class="bookly-icon-link" href="<%- settings.link.url %>">
				<% } %>
				<div class="bookly-icon">
					<i class="<%- settings.icon %>"></i>
				</div>
				<% if ( hasLink ) { %>
			</a>
			<% } %>
			<% } %>
		</div>
		<?php
	}
}
