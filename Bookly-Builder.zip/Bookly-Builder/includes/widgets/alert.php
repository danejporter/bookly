<?php
namespace Bookly;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Widget_Alert extends Widget_Base {

	public function get_id() {
		return 'alert';
	}

	public function get_title() {
		return __( 'Alert', 'bookly' );
	}

	public function get_icon() {
		return 'alert';
	}

	protected function _register_controls() {
		$this->add_control(
			'section_alert',
			[
				'label' => __( 'Alert', 'bookly' ),
				'type' => Controls_Manager::SECTION,
			]
		);

		$this->add_control(
			'alert_type',
			[
				'label' => __( 'Type', 'bookly' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'info',
				'section' => 'section_alert',
				'options' => [
					'info' => __( 'Info', 'bookly' ),
					'success' => __( 'Success', 'bookly' ),
					'warning' => __( 'Warning', 'bookly' ),
					'danger' => __( 'Danger', 'bookly' ),
				],
			]
		);

		$this->add_control(
			'alert_title',
			[
				'label' => __( 'Title & Description', 'bookly' ),
				'type' => Controls_Manager::TEXT,
				'placeholder' => __( 'Your Title', 'bookly' ),
				'default' => __( 'This is Alert', 'bookly' ),
				'label_block' => true,
				'section' => 'section_alert',
			]
		);

		$this->add_control(
			'alert_description',
			[
				'label' => '',
				'type' => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Your Description', 'bookly' ),
				'default' => __( 'I am description. Click edit button to change this text.', 'bookly' ),
				'separator' => 'none',
				'section' => 'section_alert',
			]
		);

		$this->add_control(
			'show_dismiss',
			[
				'label' => __( 'Dismiss Button', 'bookly' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'show',
				'section' => 'section_alert',
				'options' => [
					'show' => __( 'Show', 'bookly' ),
					'hide' => __( 'Hide', 'bookly' ),
				],
			]
		);

		$this->add_control(
			'view',
			[
				'label' => __( 'View', 'bookly' ),
				'type' => Controls_Manager::HIDDEN,
				'default' => 'traditional',
				'section' => 'section_alert',
			]
		);

		$this->add_control(
			'section_type',
			[
				'label' => __( 'Alert Type', 'bookly' ),
				'type' => Controls_Manager::SECTION,
				'tab' => self::TAB_STYLE,
			]
		);

		$this->add_control(
			'background',
			[
				'label' => __( 'Background Color', 'bookly' ),
				'type' => Controls_Manager::COLOR,
				'tab' => self::TAB_STYLE,
				'section' => 'section_type',
				'selectors' => [
					'{{WRAPPER}} .bookly-alert' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'border_color',
			[
				'label' => __( 'Border Color', 'bookly' ),
				'type' => Controls_Manager::COLOR,
				'tab' => self::TAB_STYLE,
				'section' => 'section_type',
				'selectors' => [
					'{{WRAPPER}} .bookly-alert' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'border_left-width',
			[
				'label' => __( 'Left Border Width', 'bookly' ),
				'type' => Controls_Manager::SLIDER,
				'tab' => self::TAB_STYLE,
				'section' => 'section_type',
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .bookly-alert' => 'border-left-width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'section_title',
			[
				'label' => __( 'Title', 'bookly' ),
				'type' => Controls_Manager::SECTION,
				'tab' => self::TAB_STYLE,
			]
		);

		$this->add_control(
			'title_color',
			[
				'label' => __( 'Text Color', 'bookly' ),
				'type' => Controls_Manager::COLOR,
				'tab' => self::TAB_STYLE,
				'section' => 'section_title',
				'selectors' => [
					'{{WRAPPER}} .bookly-alert-title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'alert_title',
				'tab' => self::TAB_STYLE,
				'section' => 'section_title',
				'selector' => '{{WRAPPER}} .bookly-alert-title',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
			]
		);

		$this->add_control(
			'section_description',
			[
				'label' => __( 'Description', 'bookly' ),
				'type' => Controls_Manager::SECTION,
				'tab' => self::TAB_STYLE,
			]
		);

		$this->add_control(
			'description_color',
			[
				'label' => __( 'Text Color', 'bookly' ),
				'type' => Controls_Manager::COLOR,
				'tab' => self::TAB_STYLE,
				'section' => 'section_description',
				'selectors' => [
					'{{WRAPPER}} .bookly-alert-description' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'alert_description',
				'tab' => self::TAB_STYLE,
				'section' => 'section_description',
				'selector' => '{{WRAPPER}} .bookly-alert-description',
				'scheme' => Scheme_Typography::TYPOGRAPHY_3,
			]
		);

	}

	protected function render( $instance = [] ) {
		if ( empty( $instance['alert_title'] ) ) {
			return;
		}

		if ( ! empty( $instance['alert_type'] ) ) {
			$this->add_render_attribute( 'wrapper', 'class', 'bookly-alert bookly-alert-' . $instance['alert_type'] );
		}

		echo '<div ' . $this->get_render_attribute_string( 'wrapper' ) . ' role="alert">';
		$html = sprintf( '<span class="bookly-alert-title">%1$s</span>', $instance['alert_title'] );

		if ( ! empty( $instance['alert_description'] ) ) {
			$html .= sprintf( '<span class="bookly-alert-description">%s</span>', $instance['alert_description'] );
		}

		if ( ! empty( $instance['show_dismiss'] ) && 'show' === $instance['show_dismiss'] ) {
			$html .= '<button type="button" class="bookly-alert-dismiss">X</button></div>';
		}

		echo $html;
	}

	protected function content_template() {
		?>
		<%
		var html = '<div class="bookly-alert bookly-alert-' + settings.alert_type + '" role="alert">';
		if ( '' !== settings.title ) {
			html += '<span class="bookly-alert-title">' + settings.alert_title + '</span>';

			if ( '' !== settings.description ) {
				html += '<span class="bookly-alert-description">' + settings.alert_description + '</span>';
			}

			if ( 'show' === settings.show_dismiss ) {
				html += '<button type="button" class="bookly-alert-dismiss">X</button></div>';
			}

			print( html );
		}
		%>
		<?php
	}
}
