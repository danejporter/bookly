<?php
namespace Bookly;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Widget_Html extends Widget_Base {

	public function get_id() {
		return 'html';
	}

	public function get_title() {
		return __( 'HTML', 'bookly' );
	}

	public function get_icon() {
		return 'coding';
	}

	protected function _register_controls() {
		$this->add_control(
			'section_title',
			[
				'label' => __( 'HTML Code', 'bookly' ),
				'type' => Controls_Manager::SECTION,
			]
		);

		$this->add_control(
			'html',
			[
				'label' => '',
				'type' => Controls_Manager::TEXTAREA,
				'default' => '',
				'placeholder' => __( 'Enter your embed code here', 'bookly' ),
				'section' => 'section_title',
			]
		);
	}

	protected function render( $instance = [] ) {
		 echo $instance['html'];
	}

	protected function content_template() {
		?>
		<%= settings.code %>
		<?php
	}
}
