<?php
namespace Bookly;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Widget_Button extends Widget_Base {

	public function get_id() {
		return 'button';
	}

	public function get_title() {
		return __( 'Button', 'bookly' );
	}

	public function get_icon() {
		return 'button';
	}

	public static function get_button_sizes() {
		return [
			'small' => __( 'Small', 'bookly' ),
			'medium' => __( 'Medium', 'bookly' ),
			'large' => __( 'Large', 'bookly' ),
			'xl' => __( 'XL', 'bookly' ),
			'xxl' => __( 'XXL', 'bookly' ),
		];
	}

	protected function _register_controls() {
		$this->add_control(
			'section_button',
			[
				'label' => __( 'Button', 'bookly' ),
				'type' => Controls_Manager::SECTION,
			]
		);

		$this->add_control(
			'button_type',
			[
				'label' => __( 'Type', 'bookly' ),
				'type' => Controls_Manager::SELECT,
				'default' => '',
				'section' => 'section_button',
				'options' => [
					'' => __( 'Default', 'bookly' ),
					'info' => __( 'Info', 'bookly' ),
					'success' => __( 'Success', 'bookly' ),
					'warning' => __( 'Warning', 'bookly' ),
					'danger' => __( 'Danger', 'bookly' ),
				],
			]
		);

		$this->add_control(
			'text',
			[
				'label' => __( 'Text', 'bookly' ),
				'type' => Controls_Manager::TEXT,
				'default' => __( 'Click me', 'bookly' ),
				'placeholder' => __( 'Click me', 'bookly' ),
				'section' => 'section_button',
			]
		);

		$this->add_control(
			'link',
			[
				'label' => __( 'Link', 'bookly' ),
				'type' => Controls_Manager::URL,
				'placeholder' => 'http://your-link.com',
				'default' => [
					'url' => '#',
				],
				'section' => 'section_button',
			]
		);

		$this->add_control(
			'align',
			[
				'label' => __( 'Alignment', 'bookly' ),
				'type' => Controls_Manager::CHOOSE,
				'section' => 'section_button',
				'options' => [
					'left'    => [
						'title' => __( 'Left', 'bookly' ),
						'icon' => 'align-left',
					],
					'center' => [
						'title' => __( 'Center', 'bookly' ),
						'icon' => 'align-center',
					],
					'right' => [
						'title' => __( 'Right', 'bookly' ),
						'icon' => 'align-right',
					],
					'justify' => [
						'title' => __( 'Justified', 'bookly' ),
						'icon' => 'align-justify',
					],
				],
				'default' => '',
			]
		);

		$this->add_control(
			'size',
			[
				'label' => __( 'Size', 'bookly' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'medium',
				'options' => self::get_button_sizes(),
				'section' => 'section_button',
			]
		);

		$this->add_control(
			'icon',
			[
				'label' => __( 'Icon', 'bookly' ),
				'type' => Controls_Manager::ICON,
				'label_block' => true,
				'default' => '',
				'section' => 'section_button',
			]
		);

		$this->add_control(
			'icon_align',
			[
				'label' => __( 'Icon Position', 'bookly' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'left',
				'options' => [
					'left' => __( 'Before', 'bookly' ),
					'right' => __( 'After', 'bookly' ),
				],
				'condition' => [
					'icon!' => '',
				],
			]
		);

		$this->add_control(
			'icon_indent',
			[
				'label' => __( 'Icon Spacing', 'bookly' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'max' => 50,
					],
				],
				'condition' => [
					'icon!' => '',
				],
				'selectors' => [
					'{{WRAPPER}} .bookly-button .bookly-align-icon-right' => 'margin-left: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .bookly-button .bookly-align-icon-left' => 'margin-right: {{SIZE}}{{UNIT}};',
				],
			]
		);

		/*
		$this->add_control(
			'hover_animation',
			[
				'label' => __( 'Hover Animation', 'bookly' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'' => __( 'None', 'bookly' ),
					'grow' => __( 'Grow', 'bookly' ),
					'shrink' => __( 'Shrink', 'bookly' ),
					'pulse-grow' => __( 'Pulse Grow', 'bookly' ),
					'pulse-shrink' => __( 'Pulse Shrink', 'bookly' ),
					'push' => __( 'Push', 'bookly' ),
					'pop' => __( 'Pop', 'bookly' ),
					'rotate' => __( 'Rotate', 'bookly' ),
					'grow-rotate' => __( 'Grow Rotate', 'bookly' ),
					'float' => __( 'Float', 'bookly' ),
					'sink' => __( 'Sink', 'bookly' ),
					'hover' => __( 'Hover', 'bookly' ),
					'wobble-vertical' => __( 'Wobble Vertical', 'bookly' ),
					'wobble-horizontal' => __( 'Wobble Horizontal', 'bookly' ),
					'buzz' => __( 'Buzz', 'bookly' ),
				],
				'default' => '',
				'tab' => self::TAB_STYLE,
			]
		);*/

		$this->add_control(
			'view',
			[
				'label' => __( 'View', 'bookly' ),
				'type' => Controls_Manager::HIDDEN,
				'default' => 'traditional',
				'section' => 'section_button',
			]
		);

		$this->add_control(
			'section_style',
			[
				'label' => __( 'Button', 'bookly' ),
				'type' => Controls_Manager::SECTION,
				'tab' => self::TAB_STYLE,
			]
		);

		$this->add_control(
			'button_text_color',
			[
				'label' => __( 'Text Color', 'bookly' ),
				'type' => Controls_Manager::COLOR,
				'tab' => self::TAB_STYLE,
				'section' => 'section_style',
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .bookly-button' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'typography',
				'label' => __( 'Typography', 'bookly' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_4,
				'tab' => self::TAB_STYLE,
				'section' => 'section_style',
				'selector' => '{{WRAPPER}} .bookly-button',
			]
		);

		$this->add_control(
			'background_color',
			[
				'label' => __( 'Background Color', 'bookly' ),
				'type' => Controls_Manager::COLOR,
				'alpha' => true,
				'tab' => self::TAB_STYLE,
				'section' => 'section_style',
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_4,
				],
				'selectors' => [
					'{{WRAPPER}} .bookly-button' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'border',
				'label' => __( 'Border', 'bookly' ),
				'tab' => self::TAB_STYLE,
				'placeholder' => '1px',
				'default' => '1px',
				'section' => 'section_style',
				'selector' => '{{WRAPPER}} .bookly-button',
			]
		);

		$this->add_control(
			'border_radius',
			[
				'label' => __( 'Border Radius', 'bookly' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'tab' => self::TAB_STYLE,
				'section' => 'section_style',
				'selectors' => [
					'{{WRAPPER}} .bookly-button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'text_padding',
			[
				'label' => __( 'Text Padding', 'bookly' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'tab' => self::TAB_STYLE,
				'section' => 'section_style',
				'selectors' => [
					'{{WRAPPER}} .bookly-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'section_hover',
			[
				'label' => __( 'Button Hover', 'bookly' ),
				'type' => Controls_Manager::SECTION,
				'tab' => self::TAB_STYLE,
			]
		);

		$this->add_control(
			'hover_color',
			[
				'label' => __( 'Text Color', 'bookly' ),
				'type' => Controls_Manager::COLOR,
				'tab' => self::TAB_STYLE,
				'section' => 'section_hover',
				'selectors' => [
					'{{WRAPPER}} .bookly-button:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'button_background_hover_color',
			[
				'label' => __( 'Background Color', 'bookly' ),
				'type' => Controls_Manager::COLOR,
				'alpha' => true,
				'tab' => self::TAB_STYLE,
				'section' => 'section_hover',
				'selectors' => [
					'{{WRAPPER}} .bookly-button:hover' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'button_hover_border_color',
			[
				'label' => __( 'Border Color', 'bookly' ),
				'type' => Controls_Manager::COLOR,
				'tab' => self::TAB_STYLE,
				'section' => 'section_hover',
				'selectors' => [
					'{{WRAPPER}} .bookly-button:hover' => 'border-color: {{VALUE}};',
				],
			]
		);
	}

	protected function render( $instance = [] ) {
		$this->add_render_attribute( 'wrapper', 'class', 'bookly-button-wrapper' );

		if ( ! empty( $instance['align'] ) ) {
			$this->add_render_attribute( 'wrapper', 'class', 'bookly-align-' . $instance['align'] );
		}

		if ( ! empty( $instance['link']['url'] ) ) {
			$this->add_render_attribute( 'button', 'href', $instance['link']['url'] );
			$this->add_render_attribute( 'button', 'class', 'bookly-button-link' );

			if ( ! empty( $instance['link']['is_external'] ) ) {
				$this->add_render_attribute( 'button', 'target', '_blank' );
			}
		}

		$this->add_render_attribute( 'button', 'class', 'bookly-button' );

		if ( ! empty( $instance['size'] ) ) {
			$this->add_render_attribute( 'button', 'class', 'bookly-size-' . $instance['size'] );
		}

		if ( ! empty( $instance['button_type'] ) ) {
			$this->add_render_attribute( 'button', 'class', 'bookly-button-' . $instance['button_type'] );
		}

		$this->add_render_attribute( 'content-wrapper', 'class', 'bookly-button-content-wrapper' );
		$this->add_render_attribute( 'icon-align', 'class', 'bookly-align-icon-' . $instance['icon_align'] );
		$this->add_render_attribute( 'icon-align', 'class', 'bookly-button-icon' );
		?>
		<div <?php echo $this->get_render_attribute_string( 'wrapper' ); ?>>
			<a <?php echo $this->get_render_attribute_string( 'button' ); ?>>
				<span <?php echo $this->get_render_attribute_string( 'content-wrapper' ); ?>>
					<?php if ( ! empty( $instance['icon'] ) ) : ?>
						<span <?php echo $this->get_render_attribute_string( 'icon-align' ); ?>>
							<i class="<?php echo esc_attr( $instance['icon'] ); ?>"></i>
						</span>
					<?php endif; ?>
					<span class="bookly-button-text"><?php echo $instance['text']; ?></span>
				</span>
			</a>
		</div>
		<?php
	}

	protected function content_template() {
		?>
		<div class="bookly-button-wrapper bookly-align-<%- settings.align %>">
			<a class="bookly-button bookly-button-<%- settings.button_type %> bookly-size-<%- settings.size %>" href="<%- settings.link.url %>">
				<span class="bookly-button-content-wrapper">
					<% if ( settings.icon ) { %>
					<span class="bookly-button-icon bookly-align-icon-<%- settings.icon_align %>">
						<i class="<%- settings.icon %>"></i>
					</span>
					<% } %>
					<span class="bookly-button-text"><%= settings.text %></span>
				</span>
			</a>
		</div>
		<?php
	}
}
