<?php
namespace Bookly;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Widget_Divider extends Widget_Base {

	public function get_id() {
		return 'divider';
	}

	public function get_title() {
		return __( 'Divider', 'bookly' );
	}

	public function get_icon() {
		return 'divider';
	}

	protected function _register_controls() {
		$this->add_control(
			'section_divider',
			[
				'label' => __( 'Divider', 'bookly' ),
				'type' => Controls_Manager::SECTION,
			]
		);

		$this->add_control(
			'style',
			[
				'label' => __( 'Style', 'bookly' ),
				'type' => Controls_Manager::SELECT,
				'section' => 'section_divider',
				'options' => [
					'solid' => __( 'Solid', 'bookly' ),
					'double' => __( 'Double', 'bookly' ),
					'dotted' => __( 'Dotted', 'bookly' ),
					'dashed' => __( 'Dashed', 'bookly' ),
				],
				'default' => 'solid',
				'selectors' => [
					'{{WRAPPER}} .bookly-divider-separator' => 'border-top-style: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'weight',
			[
				'label' => __( 'Weight', 'bookly' ),
				'type' => Controls_Manager::SLIDER,
				'section' => 'section_divider',
				'default' => [
					'size' => 1,
				],
				'range' => [
					'px' => [
						'min' => 1,
						'max' => 10,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .bookly-divider-separator' => 'border-top-width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'color',
			[
				'label' => __( 'Color', 'bookly' ),
				'type' => Controls_Manager::COLOR,
				'section' => 'section_divider',
				'default' => '',
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_3,
				],
				'selectors' => [
					'{{WRAPPER}} .bookly-divider-separator' => 'border-top-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'width',
			[
				'label' => __( 'Width', 'bookly' ),
				'type' => Controls_Manager::SLIDER,
				'default' => [
					'size' => 100,
					'unit' => '%',
				],
				'section' => 'section_divider',
				'selectors' => [
					'{{WRAPPER}} .bookly-divider-separator' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'align',
			[
				'label' => __( 'Align', 'bookly' ),
				'type' => Controls_Manager::CHOOSE,
				'section' => 'section_divider',
				'options' => [
					'left'    => [
						'title' => __( 'Left', 'bookly' ),
						'icon' => 'align-left',
					],
					'center' => [
						'title' => __( 'Center', 'bookly' ),
						'icon' => 'align-center',
					],
					'right' => [
						'title' => __( 'Right', 'bookly' ),
						'icon' => 'align-right',
					],
				],
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .bookly-divider' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'gap',
			[
				'label' => __( 'Gap', 'bookly' ),
				'type' => Controls_Manager::SLIDER,
				'default' => [
					'size' => 15,
				],
				'range' => [
					'px' => [
						'min' => 2,
						'max' => 50,
					],
				],
				'section' => 'section_divider',
				'selectors' => [
					'{{WRAPPER}} .bookly-divider' => 'padding-top: {{SIZE}}{{UNIT}}; padding-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'view',
			[
				'label' => __( 'View', 'bookly' ),
				'type' => Controls_Manager::HIDDEN,
				'default' => 'traditional',
				'section' => 'section_divider',
			]
		);
	}

	protected function render( $instance = [] ) {
		?>
		<div class="bookly-divider">
			<span class="bookly-divider-separator"></span>
		</div>
		<?php
	}

	protected function content_template() {
		?>
		<div class="bookly-divider">
			<span class="bookly-divider-separator"></span>
		</div>
		<?php
	}
}
