<?php
namespace Bookly;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Widget_Heading extends Widget_Base {

	public function get_id() {
		return 'heading';
	}

	public function get_title() {
		return __( 'Heading', 'bookly' );
	}

	public function get_icon() {
		return 'type-tool';
	}

	protected function _register_controls() {
		$this->add_control(
			'section_title',
			[
				'label' => __( 'Title', 'bookly' ),
				'type' => Controls_Manager::SECTION,
			]
		);

		$this->add_control(
			'title',
			[
				'label' => __( 'Title', 'bookly' ),
				'type' => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter your title', 'bookly' ),
				'default' => __( 'This is heading element', 'bookly' ),
				'label_block' => true,
				'section' => 'section_title',
			]
		);

		$this->add_control(
			'link',
			[
				'label' => __( 'Link', 'bookly' ),
				'type' => Controls_Manager::URL,
				'placeholder' => 'http://your-link.com',
				'default' => [
					'url' => '',
				],
				'section' => 'section_title',
				'separator' => 'before',
			]
		);

		$this->add_control(
			'size',
			[
				'label' => __( 'Size', 'bookly' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'large',
				'options' => [
					'small' => __( 'Small', 'bookly' ),
					'medium' => __( 'Medium', 'bookly' ),
					'large' => __( 'Large', 'bookly' ),
					'xl' => __( 'XL', 'bookly' ),
					'xxl' => __( 'XXL', 'bookly' ),
				],
				'section' => 'section_title',
			]
		);

		$this->add_control(
			'header_size',
			[
				'label' => __( 'HTML Tag', 'bookly' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'h1' => __( 'H1', 'bookly' ),
					'h2' => __( 'H2', 'bookly' ),
					'h3' => __( 'H3', 'bookly' ),
					'h4' => __( 'H4', 'bookly' ),
					'h5' => __( 'H5', 'bookly' ),
					'h6' => __( 'H6', 'bookly' ),
					'div' => __( 'div', 'bookly' ),
					'span' => __( 'span', 'bookly' ),
					'p' => __( 'p', 'bookly' ),
				],
				'default' => 'h2',
				'section' => 'section_title',
			]
		);

		$this->add_control(
			'align',
			[
				'label' => __( 'Alignment', 'bookly' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'bookly' ),
						'icon' => 'align-left',
					],
					'center' => [
						'title' => __( 'Center', 'bookly' ),
						'icon' => 'align-center',
					],
					'right' => [
						'title' => __( 'Right', 'bookly' ),
						'icon' => 'align-right',
					],
					'justify' => [
						'title' => __( 'Justified', 'bookly' ),
						'icon' => 'align-justify',
					],
				],
				'default' => '',
				'selectors' => [
					'{{WRAPPER}}' => 'text-align: {{VALUE}};',
				],
				'section' => 'section_title',
			]
		);

		$this->add_control(
			'view',
			[
				'label' => __( 'View', 'bookly' ),
				'type' => Controls_Manager::HIDDEN,
				'default' => 'traditional',
				'section' => 'section_title',
			]
		);

		$this->add_control(
			'section_title_style',
			[
				'label' => __( 'Title', 'bookly' ),
				'type' => Controls_Manager::SECTION,
				'tab' => self::TAB_STYLE,
			]
		);

		$this->add_control(
			'title_color',
			[
				'label' => __( 'Text Color', 'bookly' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
				    'type' => Scheme_Color::get_type(),
				    'value' => Scheme_Color::COLOR_1,
				],
				'tab' => self::TAB_STYLE,
				'section' => 'section_title_style',
				'selectors' => [
					'{{WRAPPER}} .bookly-heading-title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'typography',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'tab' => self::TAB_STYLE,
				'section' => 'section_title_style',
				'selector' => '{{WRAPPER}} .bookly-heading-title',
			]
		);
	}

	protected function render( $instance = [] ) {
		if ( empty( $instance['title'] ) )
			return;

		$this->add_render_attribute( 'heading', 'class', 'bookly-heading-title' );

		if ( ! empty( $instance['size'] ) ) {
			$this->add_render_attribute( 'heading', 'class', 'bookly-size-' . $instance['size'] );
		}

		if ( ! empty( $instance['link']['url'] ) ) {
			$url = sprintf( '<a href="%s">%s</a>', $instance['link']['url'], $instance['title'] );
			$title_html = sprintf( '<%1$s %2$s>%3$s</%1$s>', $instance['header_size'], $this->get_render_attribute_string( 'heading' ), $url );
		} else {
			$title_html = sprintf( '<%1$s %2$s>%3$s</%1$s>', $instance['header_size'], $this->get_render_attribute_string( 'heading' ), $instance['title'] );
		}

		echo $title_html;
	}

	protected function content_template() {
		?>
		<%
		if ( '' !== settings.title ) {
			var title_html = '<' + settings.header_size  + ' class="bookly-heading-title bookly-size-' + settings.size + '">' + settings.title + '</' + settings.header_size + '>';
		}
		
		if ( '' !== settings.link.url ) {
			var title_html = '<' + settings.header_size  + ' class="bookly-heading-title bookly-size-' + settings.size + '"><a href="' + settings.link.url + '">' + title_html + '</a></' + settings.header_size + '>';
		}

		print( title_html );
		%>
		<?php
	}
}
