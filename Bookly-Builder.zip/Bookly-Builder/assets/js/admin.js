( function( $, window, document ) {
	'use strict';

	var BooklyAdminApp = {

		cacheElements: function() {
			this.cache = {
				$body: $( 'body' ),
				$switchMode: $( '#bookly-switch-mode' ),
				$goToEditLink: $( '#bookly-go-to-edit-page-link' ),
				$switchModeInput: $( '#bookly-switch-mode-input' ),
				$switchModeButton: $( '#bookly-switch-mode-button' ),
				$booklyLoader: $( '#bookly-loader' ),
				$builderEditor: $( '#bookly-editor' )
			};
		},

		toggleStatus: function() {
			var isBuilderMode = 'builder' === this.getEditMode();

			this.cache.$body
			    .toggleClass( 'bookly-editor-active', isBuilderMode )
			    .toggleClass( 'bookly-editor-inactive', ! isBuilderMode );
		},

		bindEvents: function() {
			var self = this;

			self.cache.$switchModeButton.on( 'click', function( event ) {
				event.preventDefault();

				if ( 'builder' === self.getEditMode() ) {
					self.cache.$switchModeInput.val( 'editor' );
				} else {
					self.cache.$switchModeInput.val( 'builder' );

					var $wpTitle = $( '#title' );

					if ( ! $wpTitle.val() ) {
						$wpTitle.val( 'Bookly #' + $( '#post_ID' ).val() );
					}

					wp.autosave.server.triggerSave();

					self.animateLoader();

					$( document ).on( 'heartbeat-tick.autosave', function() {
						$( window ).off( 'beforeunload.edit-post' );
						window.location = self.cache.$goToEditLink.attr( 'href' );
					} );
				}

				self.toggleStatus();
			} );

			self.cache.$goToEditLink.on( 'click', function() {
				self.animateLoader();
			} );

			$( 'div.notice.bookly-message-dismissed' ).on( 'click', 'button.notice-dismiss', function( event ) {
				event.preventDefault();

				$.post( ajaxurl, {
					action: 'bookly_set_admin_notice_viewed',
					notice_id: $( this ).closest( '.bookly-message-dismissed' ).data( 'notice_id' )
				} );
			} );
		},

		init: function() {
			this.cacheElements();
			this.bindEvents();
		},

		getEditMode: function() {
			return this.cache.$switchModeInput.val();
		},

		animateLoader: function() {
			this.cache.$goToEditLink.addClass( 'bookly-animate' );
		}
	};

	$( function() {
		BooklyAdminApp.init();
	} );

}( jQuery, window, document ) );
